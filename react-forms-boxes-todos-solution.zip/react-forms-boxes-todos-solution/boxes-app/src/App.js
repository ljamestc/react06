import React from "react";
import BoxList from "./BoxList";

function App() {
  return (
    <div>
      <BoxList />
    </div>
  );
}

export default App;
